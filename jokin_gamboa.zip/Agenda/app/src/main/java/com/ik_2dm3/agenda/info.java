package com.ik_2dm3.agenda;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by ik_2dm3 on 15/12/2016.
 */


public class info extends AppCompatActivity {

    private Button volver;
    private TextView txtTlf;
    private TextView txtNombre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        //volver = (Button) findViewById(R.id.volver);
        txtNombre = (TextView) findViewById(R.id.txtNombre);
        txtTlf = (TextView) findViewById(R.id.txtTlf);

        //textView2.setText(getIntent().getStringExtra("TextoInterdimensional"));
        //txtPrinci.setText(getIntent().getStringExtra("TextoInterdimensional"));
        //Intent intent = getIntent();
        //Bundle extras = intent.getExtras();
        //String paso = extras.getString("id");
        txtNombre.setText(getIntent().getExtras().getString("idNombre"));
        txtTlf.setText(getIntent().getExtras().getString("idTlf"));
        //Toast.makeText(getBaseContext(),"Toasty dice: " + paso,Toast.LENGTH_SHORT).show();

    }
    public void llamar(View vista){
        //do stuff/*
        //int permissionCheck = ContextCompat.checkSelfPermission(this.getBaseContext(), Manifest.permission.CALL_PHONE);

        Intent callIntent = new Intent(Intent.ACTION_DIAL);

        //TextView TXTnumero = (TextView) lista.findViewById(R.id.telefono);//+"945384306";
        //MainActivity.this.lista.findViewById(R.id.telefono[i]).getTelefono();

        //String numero = TXTnumero.getText().toString();

        callIntent.setData(Uri.parse("tel:"+txtTlf.getText().toString()));
        try {
            startActivity(callIntent);
        }catch(Exception e){
            e.printStackTrace();
        }

        //Toast.makeText(getBaseContext(),"numero: " ,Toast.LENGTH_SHORT).show();
    }


    public void irSplash(View view){
        //Toast.makeText(getBaseContext(),"im tryna",Toast.LENGTH_SHORT).show();
        //Intent i = new Intent(getApplicationContext(), splash.class);

        //i.putExtra("id",txtPrinci.getText().toString());
        //startActivity(i);
    }
}
